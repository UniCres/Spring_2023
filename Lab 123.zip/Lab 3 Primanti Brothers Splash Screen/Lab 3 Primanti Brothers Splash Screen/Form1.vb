﻿Imports System.Timers

Public Class Form1
    'Shiyu Chen
    '1/31/2023
    '3rd Block
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles tmrFive.Tick
        Me.Close()
    End Sub
End Class
