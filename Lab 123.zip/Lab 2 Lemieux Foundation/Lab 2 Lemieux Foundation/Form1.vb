﻿Public Class Form1
    'Shiyu Chen
    '1/31/2023
    '3rd Block
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
